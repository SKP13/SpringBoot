package com.ness.crud.exception;

public class AuthorAlreadyDeleted extends RuntimeException{
	public AuthorAlreadyDeleted(String message)
	{
		super(message);
		
	}


}
