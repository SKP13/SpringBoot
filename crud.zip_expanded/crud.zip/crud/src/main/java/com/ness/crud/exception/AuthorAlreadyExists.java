package com.ness.crud.exception;

public class AuthorAlreadyExists extends RuntimeException {
	public AuthorAlreadyExists(String message)
	{
		super(message);
		
	}


}
